<html>
<head>
 <title>Correo hotel los bucaros</title>
</head>
<body>
<?php
$nombres=$_POST["nombres"];
$apellidos=$_POST["apellidos"];
$ciudad=$_POST["ciudad"];
$email=$_POST["email"];
$mensaje=$_POST["mensaje"];
$remitente="comercialbucaros@gmail.com";

//direcci�n del remitente

$headers = "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: $mail\r\n";

//Cuerpo del mensaje
$cuerpo .= "Nombres:" .$HTTP_POST_VARS["nombres"] . "\n"; 
$cuerpo .= "Apellidos:" .$HTTP_POST_VARS["apellidos"] . "\n"; 
$cuerpo .= "Ciudad:" .$HTTP_POST_VARS["ciudad"] . "\n"; 
$cuerpo .= "EMail:" .$HTTP_POST_VARS["email"] . "\n"; 
$cuerpo .= "Mensaje:" .$HTTP_POST_VARS["mensaje"] . "\n";

mail("$remitente","Mensaje recibido",$cuerpo);
?>
</body>
</html>


