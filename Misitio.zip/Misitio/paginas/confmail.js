// JavaScript Document
function mensaje()
{
alert("Se ha enviado un correo a : comercialbucaros@gmail.com");
setTimeout("location.href='index.html'",30);
}