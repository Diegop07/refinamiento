// JavaScript Document
function mensaje()
{
alert("Se ha enviado un correo a : diegoandrespmontoya@gmail.com");
setTimeout("location.href='index.html'",30);
}